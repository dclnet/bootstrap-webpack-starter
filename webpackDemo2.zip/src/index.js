import './style/main.css';

console.log('hello');